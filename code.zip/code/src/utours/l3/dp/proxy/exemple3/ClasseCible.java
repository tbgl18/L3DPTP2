package utours.l3.dp.proxy.exemple3;

/**
 * Classe cible utilisée par l'application.
 * L'accès à l'instance de cette classe doit être "contrôlé" (par ex. pour
 * rajouter une fonctionnalité (contrôle, log, monitoring...). Elle réalisera
 * donc, en bout de chaîne, le travail, mais ce n'est pas elle qui sera exposée
 * au client, c'est son proxy.
 */
public class ClasseCible implements InterfaceCible {

    @Override
    public String service(String data) {
        System.out.println("-> Traitement de la classe cible");
        return data + data;
    }
}
