package utours.l3.dp.proxy.exemple3;


/**
 * Demonstration du Strategy dans sa version la plus simple.
 *
 * La classe ClasseContexte expose une méthode service_soustraite()
 * qui est réalisée au moyen d'un strategy. Dans la version de base
 * il n'y a pas d'information échangée entre le contexte et son sous
 * traitant.
 */
public class Client {
    public static void main(String[] args) {
        System.out.println("Instanciation d'un objet original");
        ClasseCible objetCible = new ClasseCible() ;

        // création du proxy, l'objet cible est utilisé comme un strategy
        System.out.println("Instanciation du proxy");
        InterfaceCible objetProxy = new Proxy(objetCible);

        // usage du proxy comme si c'était l'objet cible, le résultat comprend
        // le traitement proxy et le traitement de l'objet cible
        System.out.println("Appel de la méthode du proxy");
        String res1 = objetProxy.service("5");
        System.out.println("-> " + res1);
    }
}
