package utours.l3.dp.proxy.exemple3;

/**
 * Implémentation d'un adaptateur concret.
 * Dans l'approche par classification l'adaptateur implémente l'interface de la
 * classe cible, et dérive de la classe à adapter. La sous-traitance se fait donc
 * au moyen de méthodes héritées de la classe adaptée.
 */
public class Proxy implements InterfaceCible {

    // sous-traitant utilisé par le proxy
    ClasseCible objetCible;

    /**
     * Construction du proxy comme un strategy.
     * Le constructeur reçoit le sous-traitant, ie l'objet cible masqué par le proxy.
     * Le paramètre est un objet de la classe cible, et non un objet compatible via
     * son interface; il n'est donc pas possible de faire un proxy de proxy (ce cas de
     * figure, dans le principe, existe, mais correspond à un autre DP, le décorateur).
     * @param cible [ClasseCible] objet cible utilisé par le proxy.
     */
    public Proxy(ClasseCible cible) {
        objetCible = cible;
    }

    /**
     * Service proposé par le proxy.
     */
    @Override
    public String service(String data) {
        // traitement avant sous-traitance
        System.out.println("-> Traitement du proxy, avant appel si nécessaire");
        // calcul du résultat via l'objet cible délégué
        String result = objetCible.service(data);
        // traitement après sous-traitance
        System.out.println("-> Traitement du proxy, après appel si nécessaire");
        return result;
    }
}
