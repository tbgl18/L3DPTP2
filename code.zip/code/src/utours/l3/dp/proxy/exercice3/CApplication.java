package utours.l3.dp.proxy.exercice3;


public class CApplication {
    public static void main(String[] args) {

        WebServer ws = new WebServer();

        System.out.println( ws.get("http://url_ok") );
        System.out.println( ws.get("url_bidon") );
    }
}
