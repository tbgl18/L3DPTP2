package utours.l3.dp.proxy.exercice3;

public class WebServer {
    public String get(String url) {
        // si url ne commence pas par http://, plante !
        if(url.startsWith("http://")) {
            return "Service de " + url;
        }
        else
            return "Plantage car url invalide : " + url;
    }
}
