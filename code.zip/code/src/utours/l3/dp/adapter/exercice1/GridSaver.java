package utours.l3.dp.adapter.exercice1;

public interface GridSaver {
    public void save(CGrille9x9 grille, String file);
}
