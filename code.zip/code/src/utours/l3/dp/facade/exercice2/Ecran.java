package utours.l3.dp.facade.exercice2;

/**
 * Ecran du Home Cinema
 * Se déroule ou s'enroule...
 */
public class Ecran {

    public void deployer() {
        System.out.println(" -> [ecran] : se déroule ...");
    }

}
