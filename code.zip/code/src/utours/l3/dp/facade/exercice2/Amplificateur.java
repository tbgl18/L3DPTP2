package utours.l3.dp.facade.exercice2;

/**
 * Ampliifcateur du Home Cinema
 * On peut l'allumer et régler le volume (et certainement l'éteindre aussi ;)
 */
public class Amplificateur {

    String ampliId;
    double volume;
    public Amplificateur(String id) {
        ampliId = id;
    }
    public void on() {
        System.out.println(" -> [ampli] : allumé ");
    }

    public void setVolume(double v) {
        volume = v;
        System.out.println(" -> [ampli] : volume à " + (volume*100) + " %");
    }

    public String id() {
        return ampliId + " ("+(volume*100)+"%)";
    }
}
