package utours.l3.dp.facade.exercice2;

/**
 * Le player est un lecteur (DVD, BluRay, etc.).
 * Il a besoin d'une sortie son et d'une sortie image.
 */
public class Player {

    // la sortie son
    Amplificateur sortieAudio;
    // la sortie image
    VideoProjecteur sortieVideo;

    /**
     * Affecte la sortie son
     * @param ampli [Amplificateur] objet acceptant le son
     */
    public void setSono(Amplificateur ampli) {
        sortieAudio = ampli;
    }

    /**
     * Affecte la sortie image
     * @param video [VideoProjecteur] objet acceptant l'image
     */
    public void setVideo(VideoProjecteur video) {
        sortieVideo = video;
    }

    /**
     * Allumage du player
     */
    public void on() {
        System.out.println(" -> [playr] : allumé ");
    }

    /**
     * Diffuse un enregistrement
     * @param titre [String] titre de l'oeuvre à jouer
     */
    public void play(String titre) {
        System.out.println(" -> [playr] : joue \"" + titre + "\"");
        System.out.println(" -> [playr] : son vers " + sortieAudio.id() );
        System.out.println(" -> [playr] : image vers " + sortieVideo.id() );
    }
}
