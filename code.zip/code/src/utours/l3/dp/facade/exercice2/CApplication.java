package utours.l3.dp.facade.exercice2;

/**
 * un home-cinéma est composé d’un amplificateur, d’un vidéo- projecteur,
 * d’un écran rétractable et d’un player (qui envoie l’image d’une vidéo
 * vers le vidéo-projecteur et le son vers l’amplificateur), Afin de regarder
 * un film on déroule l’écran, allume les différents appareils, règle le son
 * à mi-volume, et demande au player de jour un film (d’après son titre).
 */
public class CApplication {
    public static void main(String [] args) {
        // création des éléments nécessaires
        Amplificateur ampli = new Amplificateur("ampli01");
        VideoProjecteur video = new VideoProjecteur("videop01");
        Ecran ecran = new Ecran();
        Player player = new Player();
        // configuration de l'ensemble
        player.setSono(ampli);
        player.setVideo(video);
        ecran.deployer();
        ampli.on();
        video.on();
        player.on();
        ampli.setVolume(0.5);
        // démarre la lecture
        player.play("Lord Of The Rings");

    }
}
