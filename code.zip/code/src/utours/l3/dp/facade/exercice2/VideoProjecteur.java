package utours.l3.dp.facade.exercice2;

/**
 * Video Projecteur du Home Cinema
 * On peut l'allumer (et faire sans doute d'autres choses ...)
 */
public class VideoProjecteur {

    String videoId;
    public VideoProjecteur(String id) {
        videoId = id;
    }

    public void on() {
        System.out.println(" -> [vproj] : allumé ");
    }

    public String id() {
        return (videoId);
    }
}
